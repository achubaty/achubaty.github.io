#*******************************************
#** BISC 407: POPULATION DYNAMICS        ***
#** SINGLE SPECIES GROWTH MODELS [GUI]   ***
#** Alex M. Chubaty 2011                 ***
#*******************************************

if (!require(PBSmodelling)) {
	install.packages("PBSmodelling");
}

if (!require(deSolve)) {
	install.packages("deSolve");
}

require(PBSmodelling);
require(deSolve);

clearAll();

# Lambert W (aka ProductLog) function to solve W(z) = z exp(z) for z
lambertW = function(z,b=0,maxiter=10,eps=.Machine$double.eps,
  min.imag=1e-9) {
  if (any(round(Re(b)) != b))
    stop("branch number for W must be an integer")
  if (!is.complex(z) && any(z<0)) z=as.complex(z)
  ## series expansion about -1/e
  ##
  ## p = (1 - 2*abs(b)).*sqrt(2*e*z + 2);
  ## w = (11/72)*p;
  ## w = (w - 1/3).*p;
  ## w = (w + 1).*p - 1
  ##
  ## first-order version suffices:
  ##
  w = (1 - 2*abs(b))*sqrt(2*exp(1)*z + 2) - 1
  ## asymptotic expansion at 0 and Inf
  ##
  v = log(z + as.numeric(z==0 & b==0)) + 2*pi*b*1i;
  v = v - log(v + as.numeric(v==0))
  ## choose strategy for initial guess
  ##
  c = abs(z + exp(-1));
  c = (c > 1.45 - 1.1*abs(b));
  c = c | (b*Im(z) > 0) | (!Im(z) & (b == 1))
  w = (1 - c)*w + c*v
  ## Halley iteration
  ##
  for (n in 1:maxiter) {
    p = exp(w)
    t = w*p - z
    f = (w != -1)
    t = f*t/(p*(w + f) - 0.5*(w + 2.0)*t/(w + f))
    w = w - t
    if (abs(Re(t)) < (2.48*eps)*(1.0 + abs(Re(w)))
        && abs(Im(t)) < (2.48*eps)*(1.0 + abs(Im(w))))
      break
  }
  if (n==maxiter) warning(paste("iteration limit (",maxiter,
        ") reached, result of W may be inaccurate",sep=""))
  if (all(Im(w)<min.imag)) w = as.numeric(w)
  return(w)
}



# Lotka-Volterra Competition stuff
LVcomp <- function(t, popn, params) {
	with(as.list(c(popn, params)), {
		dN1 = r1 * N1 * ( 1 - (N1 + alpha12 * N2) / K1)
		dN2 = r2 * N2 * ( 1 - (N2 + alpha21 * N1) / K2)
		return(list(c(dN1,dN2)))
	})
}

solve_LVcomp_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	params <- list(r1=params_GUI$LVcompr1, r2=params_GUI$LVcompr2, K1=params_GUI$LVcompK1, K2=params_GUI$LVcompK2, alpha12=params_GUI$LVcompalpha12, alpha21=params_GUI$LVcompalpha21)
	popn <- c(N1=params_GUI$LVcompN10, N2=params_GUI$LVcompN20)
	time <-seq(0, 200, by=0.01)
	x <- as.data.frame( ode(func=LVcomp, y=popn, parms=params, times=time) )
	print("Ready to plot.")
	return(x)
}

plot_LVcomp_GUI <- function(solution) {	
	params <- getWinVal(scope="L");
	if (params$LVcompPDF==TRUE) { pdf("LVcomp.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	# plot N vs t
	if (params$LVcompalpha12==0) {
		params$LVcompalpha12 = .Machine$double.eps
		xlims = c(0,1.2*params$LVcompK1)
		ylims = c(0,1.2*params$LVcompK2)
	} else if (params$LVcompalpha21==0) {
		params$LVcompalpha21 = .Machine$double.eps
		xlims = c(0,1.2*params$LVcompK1)
		ylims = c(0,1.2*params$LVcompK2)
	} else {
		xlims = c(0,1.2*max(params$LVcompK1,params$LVcompK2/params$LVcompalpha21))
		ylims = c(0,1.2*max(params$LVcompK2,params$LVcompK1/params$LVcompalpha12))
	}
	plot(N1 ~ time, data=solution, type="l", lwd=2, ylim=c(0,1.5*max(N1,N2)), xlab="Time (t)", ylab="Population Size (N)", main="Lotka-Volterra Competition", col="blue")
	points(N2 ~ time, data=solution, type="l", lwd=2, lty=2, col="darkred")
	legend("topright", c("N1", "N2"), lty=c(1,1), lwd=2, col=c("blue","darkred"), box.lwd=0)
	# plot isoclines
	if (params$LVcompalpha12==0) { params$LVcompalpha12 = .Machine$double.eps }
	if (params$LVcompalpha21==0) { params$LVcompalpha21 = .Machine$double.eps }
	curve( (params$LVcompK1 - x) / params$LVcompalpha12, lwd=2, xlim=xlims, ylim=ylims, xlab=expression(N[1]), ylab=expression(N[2]), main="Isoclines", col="blue")
	curve( params$LVcompK2 - params$LVcompalpha21 * x, lwd=2, lty=2, col="darkred", add=TRUE)
	# phase plot
	plot(N2 ~ N1, data=solution, type="l", lwd=2, xlim=xlims, ylim=ylims, xlab=expression(N[1]), ylab=expression(N[2]), main="Phase Plot", col="darkgreen")
	if (params$LVcompPDF==TRUE) { 
		print("Plotted to file 'LVcomp.pdf'.")
		dev.off()
	}
}

showEqn_LVcomp <- function() {
	createWin("eqnLVcomp.win")
}

reset_default_params_LVcomp_GUI <- function() {
	setWinVal(c(LVcompr1=1.86, LVcompr2=0.86, LVcompK1=200, LVcompK2=200, LVcompalpha12=0.5, LVcompalpha21=1.5, LVcompN10=10, LVcompN20=20), "mainWinMSG")
}

# Lotka-Volterra Competition with random pop'n reduction
LVcompRand <- function(t, popn, params) {
	with(as.list(c(popn, params)), {
		epsilon = runif(n=1, min=0, max=(xi-0.1)) + 0.1
		if (epsilon > 1) {
			dN1 = r1 * N1 * ( 1 - (N1 + alpha12 * N2) / K1)
			dN2 = r2 * N2 * ( 1 - (N2 + alpha21 * N1) / K2)
		} else {
			dN1 = sigma * r1 * N1 * ( 1 - (N1 + alpha12 * N2) / K1)
			dN2 = sigma * r2 * N2 * ( 1 - (N2 + alpha21 * N1) / K2)
		}
		return(list(c(dN1,dN2)))
	})
}

solveANDplot_LVcompRand_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	params <- list(r1=params_GUI$LVcompRandr1, r2=params_GUI$LVcompRandr2, K1=params_GUI$LVcompRandK1, K2=params_GUI$LVcompRandK2, alpha12=params_GUI$LVcompRandalpha12, alpha21=params_GUI$LVcompRandalpha21, xi=params_GUI$LVcompRandxi, sigma=params_GUI$LVcompRandsigma)
	popn <- c(N1=params_GUI$LVcompRandN10, N2=params_GUI$LVcompRandN20)
	time <-seq(0, params_GUI$LVcompRandTmax, by=0.1)
	
	if (params_GUI$LVcompRandPDF==TRUE) { pdf(".pdf", height=5, width=10) }
	if (params$alpha12==0) {
		params$alpha12 = .Machine$double.eps
		xlims = c(0,1.2*params$K1)
		ylims = c(0,1.2*params$K2)
	} else if (params$alpha21==0) {
		params$alpha21 = .Machine$double.eps
		xlims = c(0,1.2*params$K1)
		ylims = c(0,1.2*params$K2)
	} else {
		xlims = c(0,1.2*max(params$K1,params$K2/params$alpha21))
		ylims = c(0,1.2*max(params$K2,params$K1/params$alpha12))
	}
	solution <- as.data.frame( ode(func=LVcompRand, y=popn, parms=params, times=time) )
	plot( N1 ~ time, data=solution, type="l", ylim=ylims, xlab="Time (t)", ylab="Population Size (N)", main="LV Competiton with Random Population Reduction", col="blue", lwd=2)
	points(N2 ~ time, data=solution, type="l", col="darkred", lwd=2)
	legend("topleft", c("N1", "N2"), lty=c(1,1), lwd=c(2,2), col=c("blue","darkred"), box.lwd=0)
	if (params_GUI$LVcompRandPDF==TRUE) { 
		print("Plotted to file 'LVcompRand.pdf'.")
		dev.off()
	}
}

plot_LVcompRand_GUI <- function(solution) {	
	params <- getWinVal(scope="L");
}

showEqn_LVcompRand <- function() {
	createWin("eqnLVcompRand.win")
}

reset_default_params_LVcompRand_GUI <- function() {
	setWinVal(c(LVcompRandr1=1.50, LVcompRandr2=1.10, LVcompRandK1=200, LVcompRandK2=200, LVcompRandalpha12=2.0, LVcompRandalpha21=0.8, LVcompRandN10=10, LVcompRandN20=10, LVcompRandxi=2, LVcompRandsigma=1, LVcompRandTmax=10), "mainWinMSG")
}

# Lotka-Volterra Predator-Prey (type I FR) with V exponential growth stuff
LVpredprey1 <- function(t, popn, params) {
	with(as.list(c(popn, params)), {
		dV = bv * V - dv * V * P
		dP = bp * V * P - dp * P
		return(list(c(dV,dP)))
	})
}

solve_LVpredprey1_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	params <- list(bv=params_GUI$LVpredprey1bv, dv=params_GUI$LVpredprey1dv, bp=params_GUI$LVpredprey1bp, dp=params_GUI$LVpredprey1dp)
	popn <- c(V=params_GUI$LVpredprey1V0, P=params_GUI$LVpredprey1P0)
	time <-seq(0, params_GUI$LVpredprey1Tmax, by=0.01)
	x <- as.data.frame( ode(func=LVpredprey1, y=popn, parms=params, times=time) )
	print("Ready to plot.")
	return(x)
}

plot_LVpredprey1_GUI <- function(solution) {	
	params <- getWinVal(scope="L");
	if (params$LVpredprey1PDF==TRUE) { pdf("LVpredprey1.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	# plot N vs t
	plot(V ~ time, data=solution, type="l", lwd=2, ylim=c(0,1.5*max(solution$V,solution$P)), xlab="Time (t)", ylab="Population Size (V,P)", main="Lotka-Volterra Predator-Prey Model", col="blue")
	points(P ~ time, data=solution, type="l", lty=1, lwd=2, col="darkred")
	legend("topright", c("V", "P"), lty=c(1,1), lwd=2, col=c("blue","darkred"), box.lwd=0)
	# blank plot
	plot.new()
	# isoclines and phase plot
	Visocline = params$LVpredprey1bv/params$LVpredprey1dv
	Pisocline = params$LVpredprey1dp/params$LVpredprey1bp
	plot(P ~ V, data=solution, type="l", lwd=2, xlim=c(0,max(solution$V)), ylim=c(0,max(solution$P)), xlab=expression(V), ylab=expression(P), main="Phase Plot", col="darkgreen")
	abline(h=Visocline, lty=2, lwd=2, col="blue")
	abline(v=Pisocline, lty=2, lwd=2, col="darkred")
	if (params$LVpredprey1PDF==TRUE) { 
		print("Plotted to file 'LVpredprey1.pdf'.")
		dev.off()
	}
}

reset_default_params_LVpredprey1_GUI <- function() {
	setWinVal(c(LVpredprey1bv=1.5, LVpredprey1dv=0.01, LVpredprey1bp=0.005, LVpredprey1dp=0.5, LVpredprey1V0=100, LVpredprey1P0=10, LVpredprey1Tmax=100), "mainWinMSG")
}

showEqn_LVpredprey1 <- function() {
	createWin("eqnLVpredprey1.win")
}

# Lotka-Volterra Predator-Prey (type I FR) with V logistic growth stuff
LVpredprey1b <- function(t, popn, params) {
	with(as.list(c(popn, params)), {
		dV = bv * V * (1 - V / K) - dv * V * P
		dP = bp * V * P - dp * P
		return(list(c(dV,dP)))
	})
}

solve_LVpredprey1b_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	params <- list(bv=params_GUI$LVpredprey1bbv, dv=params_GUI$LVpredprey1bdv, bp=params_GUI$LVpredprey1bbp, dp=params_GUI$LVpredprey1bdp, K=params_GUI$LVpredprey1bK)
	popn <- c(V=params_GUI$LVpredprey1bV0, P=params_GUI$LVpredprey1bP0)
	time <-seq(0, params_GUI$LVpredprey1bTmax, by=0.01)
	x <- as.data.frame( ode(func=LVpredprey1b, y=popn, parms=params, times=time) )
	print("Ready to plot.")
	return(x)
}

plot_LVpredprey1b_GUI <- function(solution) {	
	params <- getWinVal(scope="L");
	if (params$LVpredprey1bPDF==TRUE) { pdf("LVpredprey1b.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	# plot N vs t
	plot(V ~ time, data=solution, type="l", lwd=2, ylim=c(0,1.5*max(solution$V,solution$P)), xlab="Time (t)", ylab="Population Size (V,P)", main="Lotka-Volterra Predator-Prey Model", col="blue")
	points(P ~ time, data=solution, type="l", lty=1, lwd=2, col="darkred")
	legend("topright", c("V", "P"), lty=c(1,1), lwd=2, col=c("blue","darkred"), box.lwd=0)
	# blank plot
	plot.new()
	# isoclines and phase plot
	Visocline <- function(V) {
		x <- params$LVpredprey1bbv * ( params$LVpredprey1bK - V ) / (params$LVpredprey1bdv * params$LVpredprey1bK)
		return (x)
	}
	Pisocline = params$LVpredprey1bdp/params$LVpredprey1bbp
	plot(P ~ V, data=solution, type="l", lwd=2, xlim=c(0,max(solution$V,solution$P)), ylim=c(0,max(solution$V,solution$P)), xlab=expression(V), ylab=expression(P), main="Phase Plot", col="darkgreen")
	curve( Visocline(x), lty=2, lwd=2, col="blue", add=TRUE)
	abline(v=Pisocline, lty=2, lwd=2, col="darkred")
	if (params$LVpredprey1bPDF==TRUE) { 
		print("Plotted to file 'LVpredprey1b.pdf'.")
		dev.off()
	}
}

reset_default_params_LVpredprey1b_GUI <- function() {
	setWinVal(c(LVpredprey1bbv=1.5, LVpredprey1bdv=0.01, LVpredprey1bbp=0.005, LVpredprey1bdp=0.5, LVpredprey1bV0=100, LVpredprey1bP0=10, LVpredprey1bTmax=100), "mainWinMSG")
}

showEqn_LVpredprey1b <- function() {
	createWin("eqnLVpredprey1b.win")
}

# Lotka-Volterra Predator-Prey (type I FR) with V logistic growth stuff AND timelag
LVpredprey1c <- function(t, popn, params) {
	tlag <- t - params$tau
	if (tlag < 0) {
		popnlag <- c( popn[1], popn[2] )
	} else {
		popnlag <- lagvalue(tlag) # returns a vector
	}
	dV <- params$bv * popn[1] * (1 - popn[1]/params$K) - params$dv * popn[1] * popn[2]
	dP <- params$bp * popnlag[1] * popnlag[2] - params$dp * popn[2]
	return(list(c(dV,dP)))
}

solve_LVpredprey1c_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	params <- list(bv=params_GUI$LVpredprey1cbv, dv=params_GUI$LVpredprey1cdv, K=params_GUI$LVpredprey1cK, bp=params_GUI$LVpredprey1cbp, dp=params_GUI$LVpredprey1cdp, tau=params_GUI$LVpredprey1ctau)
	popn <- c(V=params_GUI$LVpredprey1cV0, P=params_GUI$LVpredprey1cP0)
	time <-seq(0, params_GUI$LVpredprey1cTmax, by=0.01)
	x <- as.data.frame( dede(func=LVpredprey1c, y=popn, parms=params, times=time) )
	print("Ready to plot.")
	return(x)
}

plot_LVpredprey1c_GUI <- function(solution) {	
	params <- getWinVal(scope="L");
	if (params$LVpredprey1cPDF==TRUE) { pdf("LVpredprey1blag.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	# plot N vs t
	plot(V ~ time, data=solution, type="l", lwd=2, ylim=c(0,1.5*max(solution$V,solution$P)), xlab="Time (t)", ylab="Population Size (V,P)", main="Lotka-Volterra Predator-Prey Model", col="blue")
	points(P ~ time, data=solution, type="l", lwd=2, col="darkred")
	legend("topright", c("V", "P"), lty=c(1,1), col=c("blue","darkred"), box.lwd=0, lwd=2)
	# blank plot
	plot.new()
	# phase plot
	plot(P ~ V, data=solution, type="l", lwd=2, xlim=c(0,max(solution$V)), ylim=c(0,max(solution$P)), xlab=expression(V), ylab=expression(P), main="Phase Plot", col="darkgreen")
	if (params$LVpredprey1cPDF==TRUE) { 
		print("Plotted to file 'LVpredprey1blag.pdf'.")
		dev.off()
	}
}

reset_default_params_LVpredprey1c_GUI <- function() {
	setWinVal(c(LVpredprey1cbv=0.25, LVpredprey1cdv=0.01, LVpredprey1cK=200, LVpredprey1cbp=0.01, LVpredprey1cdp=0.5, LVpredprey1cV0=100, LVpredprey1cP0=30, LVpredprey1cTmax=80), "mainWinMSG")
}

showEqn_LVpredprey1c <- function() {
	createWin("eqnLVpredprey1blag.win")
}


# Lotka-Volterra Predator-Prey (type II FR) stuff
LVpredprey2 <- function(t, popn, params) {
	k <- 1/params$th
	D <- 1 / (params$a * params$th)	
	with(as.list(c(popn, params)), {
		dV = bv * V * (1 - V / K) - dv * P * (k * V) / (D + V)
		dP = bp * k * V * P / (V + D) - dp * P
		return(list(c(dV,dP)))
	})
}

solve_LVpredprey2_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	params <- list(bv=params_GUI$LVpredprey2bv, dv=params_GUI$LVpredprey2dv, bp=params_GUI$LVpredprey2bp, dp=params_GUI$LVpredprey2dp, K=params_GUI$LVpredprey2K, a=params_GUI$LVpredprey2a, th=params_GUI$LVpredprey2th)
	popn <- c(V=params_GUI$LVpredprey2V0, P=params_GUI$LVpredprey2P0)
	time <-seq(0, params_GUI$LVpredprey2Tmax, by=0.01)
	x <- as.data.frame( ode(func=LVpredprey2, y=popn, parms=params, times=time) )
	print("Ready to plot.")
	return(x)
}

plot_LVpredprey2_GUI <- function(solution) {	
	params <- getWinVal(scope="L");
	if (params$LVpredprey2PDF==TRUE) { pdf("LVpredprey2.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	# plot N vs t
	plot(V ~ time, data=solution, type="l", lwd=2, ylim=c(0,1.5*max(solution$V,solution$P)), xlab="Time (t)", ylab="Population Size (V,P)", main="Lotka-Volterra Predator-Prey Model", col="blue")
	points(P ~ time, data=solution, type="l", lty=1, lwd=2, col="darkred")
	legend("topright", c("V", "P"), lty=c(1,1), lwd=2, col=c("blue","darkred"), box.lwd=0)
	# blank plot
	plot.new()
	# isoclines and phase plot
	Visocline <- function(V) {
		x <- params$LVpredprey2bv * ( params$LVpredprey2K - V ) * (1 + params$LVpredprey2a * params$LVpredprey2th * V) / (params$LVpredprey2a * params$LVpredprey2dv * params$LVpredprey2K)
		return (x)
	}
	Pisocline = params$LVpredprey2dp / (params$LVpredprey2a * (params$LVpredprey2bp - params$LVpredprey2dp * params$LVpredprey2th))
	plot(P ~ V, data=solution, type="l", lwd=2, xlim=c(0,1.2*max(solution$V)), ylim=1.2*c(0,max(solution$P)), xlab=expression(V), ylab=expression(P), main="Phase Plot", col="darkgreen")
	curve( Visocline(x), lty=2, lwd=2, col="blue", add=TRUE)
	abline(v=Pisocline, lty=2, lwd=2, col="darkred")
	if (params$LVpredprey2PDF==TRUE) { 
		print("Plotted to file 'LVpredprey2.pdf'.")
		dev.off()
	}
}

reset_default_params_LVpredprey2_GUI <- function() {
	setWinVal(c(LVpredprey2bv=0.8, LVpredprey2dv=0.01, LVpredprey2bp=0.05, LVpredprey2dp=0.1,LVpredprey2K=200, LVpredprey2a=0.1,  LVpredprey2th=0.05, LVpredprey2V0=100, LVpredprey2P0=10, LVpredprey2Tmax=100), "mainWinMSG")
}

showEqn_LVpredprey2 <- function() {
	createWin("eqnLVpredprey2.win")
}

# Lotka-Volterra Predator-Prey (type III FR) stuff
LVpredprey3 <- function(t, popn, params) {
	k <- 1/params$th
	D <- 1 / (params$a * params$th)	
	with(as.list(c(popn, params)), {
		dV = bv * V * (1 - V / K) - dv * P * (k * V^2) / (D^2 + V^2)
		dP = bp * k * P * V^2 / (D^2 + V^2) - dp * P
		return(list(c(dV,dP)))
	})
}

solve_LVpredprey3_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	params <- list(bv=params_GUI$LVpredprey3bv, dv=params_GUI$LVpredprey3dv, bp=params_GUI$LVpredprey3bp, dp=params_GUI$LVpredprey3dp, K=params_GUI$LVpredprey3K, a=params_GUI$LVpredprey3a, th=params_GUI$LVpredprey3th)
	popn <- c(V=params_GUI$LVpredprey3V0, P=params_GUI$LVpredprey3P0)
	time <-seq(0, params_GUI$LVpredprey3Tmax, by=0.01)
	x <- as.data.frame( ode(func=LVpredprey3, y=popn, parms=params, times=time) )
	print("Ready to plot.")
	return(x)
}

plot_LVpredprey3_GUI <- function(solution) {	
	params <- getWinVal(scope="L");
	if (params$LVpredprey3PDF==TRUE) { pdf("LVpredprey3.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	# plot N vs t
	plot(V ~ time, data=solution, type="l", lwd=2, ylim=c(0,1.5*max(solution$V,solution$P)), xlab="Time (t)", ylab="Population Size (V,P)", main="Lotka-Volterra Predator-Prey Model", col="blue")
	points(P ~ time, data=solution, type="l", lty=1, lwd=2, col="darkred")
	legend("topright", c("V", "P"), lty=c(1,1), lwd=2, col=c("blue","darkred"), box.lwd=0)
	# blank plot
	plot.new()
	# phase plot
	k <- 1/params$LVpredprey3th
	D <- 1 / (params$LVpredprey3a * params$LVpredprey3th)	
	Visocline <- function(V) {
		x <- params$LVpredprey3bv * (D^2 + V^2) * (1 - V / params$LVpredprey3K) / (params$LVpredprey3dv * k * V)
		return (x)
	}
	if (params$LVpredprey3dp < params$LVpredprey3bp * k) {
		Pisocline = D * sqrt(params$LVpredprey3dp) / sqrt(-(params$LVpredprey3dp - params$LVpredprey3bp * k))
	}
	plot(P ~ V, data=solution, type="l", lwd=2, xlim=c(0,1.2*max(solution$V)), ylim=1.2*c(0,max(solution$P)), xlab=expression(V), ylab=expression(P), main="Phase Plot", col="darkgreen")
	curve( Visocline(x), lty=2, lwd=2, col="blue", add=TRUE)
	if (params$LVpredprey3dp < params$LVpredprey3bp * k) {
		abline(v=Pisocline, lty=2, lwd=2, col="darkred")
	}
	if (params$LVcompPDF==TRUE) { 
		print("Plotted to file 'LVpredprey3.pdf'.")
		dev.off()
	}
}

reset_default_params_LVpredprey3_GUI <- function() {
	setWinVal(c(LVpredprey3bv=1.5, LVpredprey3dv=0.01, LVpredprey3K=200, LVpredprey3bp=0.005, LVpredprey3dp=0.5, LVpredprey3a=1, LVpredprey3th=0.5, LVpredprey3V0=100, LVpredprey3P0=10), "mainWinMSG")
}

showEqn_LVpredprey3 <- function() {
	createWin("eqnLVpredprey3.win")
}

# vampire popultion model :[
vampires <- function(t, popn, params) {
	with(as.list(c(popn, params)), {
		dH = r * H * (K - H) / K - a * H * V
		dV = b * a * H * V + m * V - s * V
		return(list(c(dH,dV)))
	})
}

solve_vampire_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	params <- list(r=params_GUI$vampr, K=params_GUI$vampK, a=params_GUI$vampa, b=params_GUI$vampb, m=params_GUI$vampm, s=params_GUI$vamps)
	popn <- c(H=params_GUI$vampH0, V=params_GUI$vampV0)
	time <-seq(0, 200, by=0.01)
	x <- as.data.frame( ode(func=vampires, y=popn, parms=params, times=time, maxsteps=10^6) )
	print("Ready to plot.")
	return(x)
}

plot_vampire_GUI <- function(solution) {	
	params <- getWinVal(scope="L");
	if (params$vampPDF==TRUE) { pdf("vampires.pdf", height=10, width=10) }
	layout(matrix(c(1,2,3,4), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	# plot N vs t
	plot(H ~ time, data=solution, type="l", lwd=2, ylim=c(0,1.5*max(solution$H)), xlab="Time (t)", ylab=expression(H), main="Human Population Size Over Time", col="blue")
	plot(V ~ time, data=solution, type="l", lwd=2, ylim=c(0,1.5*max(solution$V)), xlab="Time (t)", ylab=expression(V), main="Vampire Population Size Over Time", col="darkred")
	# isoclines
	plot.new()
	# phase plot
	plot(V ~ H, data=solution, type="l", lwd=2, xlim=c(0,max(solution$H,solution$V)), ylim=c(0,max(solution$V)), xlab=expression(H), ylab=expression(V), main="Phase Plot", col="darkgreen")
	H.hat <- (params$vamps - params$vampm)/(params$vampb * params$vampa)
	V.hat <- (params$vampr / params$vampa) * (1 + (params$vampm - params$vamps)/(params$vampb * params$vampa * params$vampK))
	abline(h=V.hat, lty=2, lwd=2, col="blue")
	abline(v=H.hat, lty=2, lwd=2, col="darkred")
	if (params$vampPDF==TRUE) { 
		print("Plotted to file 'vampires.pdf'.")
		dev.off()
	}
}

reset_default_params_vampire_GUI <- function() {
	setWinVal(c(vampr=log(1.10), vampK=100000, vampa=1/300, vampb=1/240, vampm=log(1.10), vamps=0.6, vampH0=10000, vampV0=10), "mainWinMSG")
}

showEqn_vampire <- function() {
	createWin("eqnVampires.win")
}



# Nicholson-Bailey stuff
NB <- function(H0, P0, Tmax, R, a, c) {
	x <- array( data=NA, dim=c(Tmax+1,3), dimnames=list(NULL,c("t","H[t]","P[t]")) )	# prepare array to store data
	x[,1] <- 0:Tmax				# fill in 't' values in first column
	x[1,2] <- H0				# set initial host population size to H0
	x[1,3] <- P0				# set initial parasitoid population size to H0
	for(t in 1:Tmax){			# loop to calculate Nt+1 at each time step
		x[t+1,2] <- x[t,2] * R * exp(-a * x[t,3])		# host population
		x[t+1,3] <- c * x[t,2] * ( 1 - exp(-a * x[t,3]) )	# parasitoid population
	}
	return(x)				# return the array
}

solve_NB_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	params <- list(H0=params_GUI$nbH0, P0=params_GUI$nbP0, Tmax=params_GUI$nbTmax, R=params_GUI$nbR, a=params_GUI$nba, c=params_GUI$nbc)
	x <- NB(params$H0, params$P0, params$Tmax, params$R, params$a, params$c)
	print("Ready to plot.")
	return(x)
}

plot_NB_GUI <- function(solution) {
	params <- getWinVal(scope="L");
	if (params$nbPDF==TRUE) { pdf("nicholson-bailey.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	# dynamics
	plot( solution[,1:2], pch=20, type="b", ylim=c(0,max(solution[,2:3])), xlab="Time (t)", ylab=expression(N[t]), main="Nicholson-Bailey Model", lwd=2, cex=1.2, cex.main=1.2, cex.lab=1.2, col="blue" )
	points( solution[,c(1,3)], pch=20, type="b", lwd=2, cex=1.2, col="darkred")
	legend("topleft", legend=c("host", "parasitoid"), cex=1.2, fill=c("blue", "darkred"), box.lwd=0)
	# blank plot
	plot.new()
	# phase plot
	plot( solution[,2:3], pch=20, type="l", xlab=expression(H[t]), ylab=expression(P[t]), lwd=2, cex.lab=1.2, col="darkgreen" )
	abline(h=(1/params$nba)*log(params$nbR), lwd=2, lty=2, col="blue")
	curve(params$nbc*x + lambertW(-params$nba*params$nbc*exp(-params$nba*params$nbc*x)*x)/params$nba, lwd=2, lty=2, col="darkred", add=TRUE)
	if (params$nbPDF==TRUE) {
		print("Plotted to file 'nicholson-bailey.pdf'.")
		dev.off()
	}
}

reset_default_params_NB_GUI <- function() {
	setWinVal(c(nbR=1.77, nba=0.03, nbc=1, nbTmax=60, nbH0=44, nbP0=19), "mainWinMSG")
}

showEqn_NB <- function() {
	createWin("eqnNB.win")
}

# add K to basic NB model
NBK <- function(H0, P0, Tmax, R, K, a, c) {
	x <- array( data=NA, dim=c(Tmax+1,3), dimnames=list(NULL,c("t","H[t]","P[t]")) )	# prepare array to store data
	x[,1] <- 0:Tmax				# fill in 't' values in first column
	x[1,2] <- H0				# set initial host population size to H0
	x[1,3] <- P0				# set initial parasitoid population size to H0
	for(t in 1:Tmax){			# loop to calculate Nt+1 at each time step
		x[t+1,2] <- x[t,2] * R * (1 - x[t,2] / K) * exp(-a * x[t,3])		# host population
		x[t+1,3] <- c * x[t,2] * ( 1 - exp(-a * x[t,3]) )	# parasitoid population
	}
	return(x)				# return the array
}

solve_NBK_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	params <- list(H0=params_GUI$nbkH0, P0=params_GUI$nbkP0, Tmax=params_GUI$nbkTmax, R=params_GUI$nbkR, K=params_GUI$nbkK, a=params_GUI$nbka, c=params_GUI$nbkc)
	x <- NBK(params$H0, params$P0, params$Tmax, params$R, params$K, params$a, params$c)
	print("Ready to plot.")
	return(x)
}

plot_NBK_GUI <- function(solution) {
	params <- getWinVal(scope="L");
	if (params$nbkPDF==TRUE) { pdf("nicholson-bailey-K.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	# dynamics
	plot( solution[,1:2], pch=20, type="b", ylim=c(0,max(solution[,2:3])+25), xlab="Time (t)", ylab=expression(N[t]), main="Nicholson-Bailey Model with Host Carrying Capacity", lwd=2, cex=1.2, cex.main=1.2, cex.lab=1.2, col="blue" )
	points( solution[,c(1,3)], pch=20, type="b", lwd=2, cex=1.2, col="darkred")
	legend("topleft", legend=c("host", "parasitoid"), cex=1.2, fill=c("blue", "darkred"))
	# blank plot
	plot.new()
	# phase plot
	plot( solution[,2:3], pch=20, type="l", xlab=expression(H[t]), ylab=expression(P[t]), lwd=2, cex.lab=1.2, col="darkgreen" )
	curve((1/params$nbka)*log(params$nbkR*(1-x/params$nbkK)), lwd=2, lty=2, col="blue", add=TRUE)
	curve(params$nbkc*x+lambertW(-params$nbka * params$nbkc * exp(-params$nbka*params$nbkc*x) * x)/params$nbka, lwd=2, lty=2, col="darkred", add=TRUE)
	if (params$nbkPDF==TRUE) {
		print("Plotted to file 'nicholson-bailey-K.pdf'.")
		dev.off()
	}
}

reset_default_params_NBK_GUI <- function() {
	setWinVal(c(nbkR=1.77, nbkK=200, nbka=0.03, nbkc=1, nbkTmax=60, nbkH0=44, nbkP0=19), "mainWinMSG")
}

showEqn_NBK <- function() {
	createWin("eqnNBK.win")
}


# add type II functional response to basic NB model
NBfr2 <- function(H0, P0, Tmax, R, Th, a, c) {
	x <- array( data=NA, dim=c(Tmax+1,3), dimnames=list(NULL,c("t","H[t]","P[t]")) )	# prepare array to store data
	x[,1] <- 0:Tmax				# fill in 't' values in first column
	x[1,2] <- H0				# set initial host population size to H0
	x[1,3] <- P0				# set initial parasitoid population size to H0
	for(t in 1:Tmax){			# loop to calculate Nt+1 at each time step
		x[t+1,2] <- x[t,2] * R * exp(-a * x[t,3] / (1 + a * Th * x[t,2]) )		# host population
		x[t+1,3] <- c * x[t,2] * ( 1 - exp(-a * x[t,3] / (1 + a * Th * x[t,2]) ) )	# parasitoid population
	}
	return(x)				# return the array
}

solve_NBfr2_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	params <- list(H0=params_GUI$nbfr2H0, P0=params_GUI$nbfr2P0, Tmax=params_GUI$nbfr2Tmax, R=params_GUI$nbfr2R, Th=params_GUI$nbfr2Th, a=params_GUI$nbfr2a, c=params_GUI$nbfr2c)
	x <- NBfr2(params$H0, params$P0, params$Tmax, params$R, params$Th, params$a, params$c)
	print("Ready to plot.")
	return(x)
}

plot_NBfr2_GUI <- function(solution) {
	params <- getWinVal(scope="L");
	if (params$nbfr2PDF==TRUE) { pdf("nicholson-bailey-fr2.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	# dynamics
	plot( solution[,1:2], pch=20, type="b", ylim=c(0,max(solution[,2:3])+25), xlab="Time (t)", ylab=expression(N[t]), main="Nicholson-Bailey Model with Type II Functional Response", cex=1.2, cex.main=1.2, cex.lab=1.2, col="blue", lwd=2 )
	points( solution[,c(1,3)], pch=20, type="b", cex=1.2, col="darkred", lwd=2)
	legend("topleft", legend=c("host", "parasitoid"), cex=1.2, fill=c("blue", "darkred"), box.lwd=0)
	# blank plot
	plot.new()
	# phase plot
	plot( solution[,2:3], pch=20, type="l", xlab=expression(H[t]), ylab=expression(P[t]), lwd=2, cex.lab=1.2, col="darkgreen" )
	curve((1/params$nbfr2a)*log(params$nbfr2R)*(1 + params$nbfr2a*params$nbfr2Th*x), lwd=2, lty=2, col="blue", add=TRUE)
	curve(params$nbfr2c*x+(1/params$nbfr2a + x*params$nbfr2Th)*lambertW(-params$nbfr2a*params$nbfr2c*exp(-params$nbfr2a*params$nbfr2c*x/(1+params$nbfr2a*params$nbfr2Th*x))*x / (1+params$nbfr2a*params$nbfr2Th*x)), lwd=2, lty=2, col="darkred", add=TRUE)
	if (params$nbfr2PDF==TRUE) {
		print("Plotted to file 'nicholson-bailey-fr2.pdf'.")
		dev.off()
	}
}

reset_default_params_NBfr2_GUI <- function() {
	setWinVal(c(nbfr2R=1.77, nbfr2Th=0.5, nbfr2a=0.03, nbfr2c=1, nbfr2Tmax=60, nbfr2H0=44, nbfr2P0=19), "mainWinMSG")
}

showEqn_NBfr2 <- function() {
	createWin("eqnNBfr2.win")
}



# add type II functional response to NBK model
NBKfr2 <- function(H0, P0, Tmax, R, K, Th, a, c) {
	x <- array( data=NA, dim=c(Tmax+1,3), dimnames=list(NULL,c("t","H[t]","P[t]")) )	# prepare array to store data
	x[,1] <- 0:Tmax				# fill in 't' values in first column
	x[1,2] <- H0				# set initial host population size to H0
	x[1,3] <- P0				# set initial parasitoid population size to H0
	for(t in 1:Tmax){			# loop to calculate Nt+1 at each time step
		x[t+1,2] <- x[t,2] * R * (1 - x[t,2]/K) * exp(-a * x[t,3] / (1 + a * Th * x[t,2]) )	# host population
		x[t+1,3] <- c * x[t,2] * ( 1 - exp(-a * x[t,3] / (1 + a * Th * x[t,2]) ) )	# parasitoid population
	}
	return(x)				# return the array
}

solve_NBKfr2_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	params <- list(H0=params_GUI$nbkfr2H0, P0=params_GUI$nbkfr2P0, Tmax=params_GUI$nbkfr2Tmax, R=params_GUI$nbkfr2R, K=params_GUI$nbkfr2K, Th=params_GUI$nbkfr2Th, a=params_GUI$nbkfr2a, c=params_GUI$nbkfr2c)
	x <- NBKfr2(params$H0, params$P0, params$Tmax, params$R, params$K, params$Th, params$a, params$c)
	print("Ready to plot.")
	return(x)
}

plot_NBKfr2_GUI <- function(solution) {
	params <- getWinVal(scope="L");
	if (params$nbkfr2PDF==TRUE) { pdf("nicholson-bailey-K-fr2.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	# dynamics
	plot( solution[,1:2], pch=20, type="b", ylim=c(0,max(solution[,2:3])+25), xlab="Time (t)", ylab=expression(N[t]), main="Nicholson-Bailey Model with host K and Type II Functional Response", lwd=2, cex=1.2, cex.main=1.2, cex.lab=1.2, col="blue" )
	points( solution[,c(1,3)], pch=20, type="b", lwd=2, cex=1.2, col="darkred")
	legend("topleft", legend=c("host", "parasitoid"), cex=1.2, fill=c("blue", "darkred"), box.lwd=0)
	# blank plot
	plot.new()
	# phase plot
	plot( solution[,2:3], pch=20, type="l", xlim=c(0,max(solution[,2])+25), ylim=c(0,max(solution[,3])+25),xlab=expression(H[t]), ylab=expression(P[t]), lwd=2, cex.lab=1.2, col="darkgreen" )
	curve((1/params$nbkfr2a)*log(params$nbkfr2R-params$nbkfr2R*x/params$nbkfr2K)*(1 + params$nbkfr2a*params$nbkfr2Th*x), lwd=2, lty=2, col="blue", add=TRUE)
	curve(params$nbfr2c*x+(1/params$nbfr2a + x*params$nbfr2Th)*lambertW(-params$nbfr2a*params$nbfr2c*exp(-params$nbfr2a*params$nbfr2c*x/(1+params$nbfr2a*params$nbfr2Th*x))*x / (1+params$nbfr2a*params$nbfr2Th*x)), lwd=2, lty=2, col="darkred", add=TRUE)
	if (params$nbkfr2PDF==TRUE) {
		print("Plotted to file 'nicholson-bailey-K-fr2.pdf'.")
		dev.off()
	}
}

reset_default_params_NBKfr2_GUI <- function() {
	setWinVal(c(nbkfr2R=1.77, nbkfr2K=200, nbkfr2Th=0.5, nbkfr2a=0.03, nbkfr2c=1, nbkfr2Tmax=60, nbkfr2H0=44, nbkfr2P0=19), "mainWinMSG")
}

showEqn_NBKfr2 <- function() {
	createWin("eqnNBKfr2.win")
}



createWin("407.MSG.models.win")

