#*******************************************
#** BISC 407: POPULATION DYNAMICS        ***
#** SINGLE SPECIES GROWTH MODELS [GUI]   ***
#** Alex M. Chubaty 2011                 ***
#*******************************************

if (!require(PBSmodelling)) {
	install.packages("PBSmodelling");
}

if (!require(deSolve)) {
	install.packages("deSolve");
}

if (!require(scatterplot3d)) {
	install.packages("scatterplot3d");
}

require(PBSmodelling);
require(deSolve);
require(scatterplot3d);

clearAll();

# simple SIR model (eqns 3.19 Otto & Day, p78) 
SIR <- function(t, popn, params) {
	with(as.list(c(popn, params)), {
		dS = theta - d * S - a * c * S * I + sigma * R
		dI = a * c * S * I - delta * I - rho * I
		dR = rho * I - sigma * R - d * R
		return(list(c(dS,dI,dR)))
	})
}

solve_SIR_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	params <- list(a=params_GUI$SIRa, c=params_GUI$SIRc, d=params_GUI$SIRd, delta=params_GUI$SIRdelta, rho=params_GUI$SIRrho, sigma=params_GUI$SIRsigma, theta=params_GUI$SIRtheta)
	popn <- c(S=params_GUI$SIRS0, I=params_GUI$SIRI0, R=params_GUI$SIRR0)
	time <-seq(0, params_GUI$SIRTmax, by=0.01)
	x <- as.data.frame( ode(func=SIR, y=popn, parms=params, times=time) )
	print("Ready to plot.")
	return(x)
}

plot_SIR_GUI <- function(solution) {	
	params <- getWinVal(scope="L");
	if (params$SIRPDF==TRUE) { pdf("SIR.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	# plot N vs t
	plot(S ~ time, data=solution, type="l", lty=1, lwd=2, ylim=c(0,1.5*max(S,I,R)), xlab="Time (t)", ylab="Number of Individuals (S,I,R)", main="A simple SIR model", col="blue")
	points(I ~ time, data=solution, type="l", lty=2, lwd=2, col="darkred")
	points(R ~ time, data=solution, type="l", lty=3, lwd=2, col="darkgreen")
	legend("topright", c("S", "I","R"), lty=c(1,2,3), lwd=2, col=c("blue","darkred","darkgreen"), box.lwd=0)
	# blank plot
	plot.new()
	# phase plot
	scatterplot3d(solution$S, solution$R, solution$I, type="l", lwd=2, xlim=c(0,max(solution$S)), ylim=c(0,max(solution$R)), zlim=c(0,max(solution$I)), xlab=expression(S), ylab=expression(R), zlab=expression(I), main="Phase Plot", highlight.3d=TRUE)
	if (params$SIRPDF==TRUE) { 
		print("Plotted to file 'SIR.pdf'.")
		dev.off()
	}
}

showEqn_SIR <- function() {
	createWin("eqnSIR.win")
}

reset_default_params_SIR_GUI <- function() {
	setWinVal(c(SIRa=0.1, SIRc=0.01, SIRd=0.01, SIRdelta=0.02, SIRrho=0.2, SIRsigma=0.05, SIRtheta=10, SIRTmax=200, SIRS0=900, SIRI0=90, SIRR0=10), "mainWinDisease")
}


# a measels SIR model (from lecture) 
measels <- function(t, popn, params) {
	with(as.list(c(popn, params)), {
		dX = b * (X+Y+Z) + alpha * Y - beta * X * Y - b * X
		dY = beta * X * Y - (alpha + b + nu) * Y
		dZ = nu * Y - b * Z
		return(list(c(dX,dY,dZ)))
	})
}

solve_measels_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	params <- list(b=params_GUI$measelsb, alpha=params_GUI$measelsalpha, beta=params_GUI$measelsbeta, nu=params_GUI$measelsnu)
	popn <- c(X=params_GUI$measelsX0, Y=params_GUI$measelsY0, Z=params_GUI$measelsZ0)
	time <-seq(0, params_GUI$measelsTmax, by=0.01)
	x <- as.data.frame( ode(func=measels, y=popn, parms=params, times=time) )
	print("Ready to plot.")
	return(x)
}

plot_measels_GUI <- function(solution) {	
	params <- getWinVal(scope="L");
	if (params$measelsPDF==TRUE) { pdf("measels.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	# plot N vs t
	plot(X ~ time, data=solution, type="l", lty=1, lwd=2, ylim=c(0,1.5*max(X,Y,Z)), xlab="Time (t)", ylab="Number of Individuals (X, Y, Z)", main="A measels epidemiology model", col="blue")
	points(Y ~ time, data=solution, type="l", lty=2, lwd=2, col="darkred")
	points(Z ~ time, data=solution, type="l", lty=3, lwd=2, col="darkgreen")
	legend("topright", c("X", "Y","Z"), lty=c(1,2,3), lwd=2, col=c("blue","darkred","darkgreen"), box.lwd=0)
	# blank plot
	plot.new()
	# phase plot
	scatterplot3d(solution$X, solution$Z, solution$Y, type="l", lwd=2, xlim=c(0,max(solution$X)), ylim=c(0,max(solution$Z)), zlim=c(0,max(solution$Y)), xlab=expression(X), ylab=expression(Z), zlab=expression(Y), main="Phase Plot", highlight.3d=TRUE)
	if (params$measelsPDF==TRUE) { 
		print("Plotted to file 'measels.pdf'.")
		dev.off()
	}
}

showEqn_measels <- function() {
	createWin("eqnMeasels.win")
}

reset_default_params_measels_GUI <- function() {
	setWinVal(c(measelsb=0.01, measelsalpha=0.02, measelsbeta=0.001, measelsnu=0.2, measelsTmax=200, measelsX0=900, measelsY0=90, measelsZ0=10), "mainWinDisease")
}

# an AIDS SIR model (from lecture) -- needs proper parameterization
AIDS <- function(t, popn, params) {
	with(as.list(c(popn, params)), {
		dX = b * (X+Y1+Y2+Z+A) + alpha * A - (b + lambda) * X
		dY1 = f * lambda * X - (b + nu1) * Y1
		dY2 = (1-f) * lambda * X - (b + nu2) * Y2
		dZ = nu2 * Y2 - b * Z
		dA = nu1 * Y1 - (b + alpha) * A
		return(list(c(dX,dY1,dY2,dZ,dA)))
	})
}

solve_AIDS_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	params <- list(b=params_GUI$AIDSb, f=params_GUI$AIDSf, alpha=params_GUI$AIDSalpha, beta=params_GUI$AIDSbeta, lambda=params_GUI$AIDSlambda, nu1=params_GUI$AIDSnu1, nu2=params_GUI$AIDSnu2)
	popn <- c(X=params_GUI$AIDSX0, Y1=params_GUI$AIDSY10, Y2=params_GUI$AIDSY20, Z=params_GUI$AIDSZ0, A=params_GUI$AIDSA0)
	time <-seq(0, params_GUI$AIDSTmax, by=0.01)
	x <- as.data.frame( ode(func=AIDS, y=popn, parms=params, times=time) )
	print("Ready to plot.")
	return(x)
}

plot_AIDS_GUI <- function(solution) {	
	params <- getWinVal(scope="L");
	if (params$AIDSPDF==TRUE) { pdf("AIDS.pdf", height=5, width=10) }
	# plot N vs t
	plot(X ~ time, data=solution, type="l", lty=1, lwd=2, ylim=c(0,1.5*max(X,Y1,Y2,Z,A)), xlab="Time (t)", ylab="Number of Individuals (X, Y1, Y2, Z, A)", main="An AIDS epidemiology model", col="blue")
	points(Y1 ~ time, data=solution, type="l", lty=2, lwd=2, col="darkred")
	points(Y2 ~ time, data=solution, type="l", lty=3, lwd=2, col="darkgreen")
	points(Z ~ time, data=solution, type="l", lty=4, lwd=2, col="orange")
	points(A ~ time, data=solution, type="l", lty=5, lwd=2, col="purple")
	legend("topright", c("X", "Y1","Y2","Z","A"), lty=c(1,2,3,4,5), lwd=2, col=c("blue","darkred","darkgreen","orange","purple"), box.lwd=0)
	if (params$AIDSPDF==TRUE) { 
		print("Plotted to file 'AIDS.pdf'.")
		dev.off()
	}
}

showEqn_AIDS <- function() {
	createWin("eqnAIDS.win")
}

reset_default_params_AIDS_GUI <- function() {
	setWinVal(c(AIDSb=0.01, AIDSf=0.1, AIDSalpha=0.02, AIDSbeta=0.001, AIDSlambda=0.1, AIDSnu1=0.2, AIDSnu2=0.2, AIDSTmax=200, AIDSX0=9000, AIDSY10=500, AIDSY20=400, AIDSZ0=60, AIDSA0=40), "mainWinDisease")
}

# zombie infection model (basic) -- from Munz et al. (2009)
zombie0 <- function(t, popn, params) {
	with(as.list(c(popn, params)), {
		dS = Pi - beta * S * Z - delta * S
		dZ = beta * S * Z + zeta * R - alpha * S * Z
		dR = delta * S + alpha * S * Z - zeta * R
		return(list(c(dS,dZ,dR)))
	})
}

solve_zombie0_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	params <- list(alpha=params_GUI$zombie0alpha, beta=params_GUI$zombie0beta, delta=params_GUI$zombie0delta, Pi=params_GUI$zombie0Pi, zeta=params_GUI$zombie0zeta)
	popn <- c(S=params_GUI$zombie0S0, Z=params_GUI$zombie0Z0, R=params_GUI$zombie0R0)
	time <-seq(0, params_GUI$zombie0Tmax, by=0.01)
	x <- as.data.frame( ode(func=zombie0, y=popn, parms=params, times=time) )
	print("Ready to plot.")
	return(x)
}

plot_zombie0_GUI <- function(solution) {	
	params <- getWinVal(scope="L");
	if (params$zombie0PDF==TRUE) { pdf("zombie0.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	# plot N vs t
	plot(S ~ time, data=solution, type="l", lty=1, lwd=2, ylim=c(0,1.5*max(S,Z,R)), xlab="Time (t)", ylab="Number of Individuals (S,Z,R)", main="A simple zombie infection model", col="blue")
	points(Z ~ time, data=solution, type="l", lty=2, lwd=2, col="darkred")
	points(R ~ time, data=solution, type="l", lty=3, lwd=2, col="darkgreen")
	legend("topright", c("S", "Z","R"), lty=c(1,2,3), lwd=2, col=c("blue","darkred","darkgreen"), box.lwd=0)
	# blank plot
	plot.new()
	# phase plot
	scatterplot3d(solution$S, solution$R, solution$Z, type="l", lwd=2, xlim=c(0,max(solution$S)), ylim=c(0,max(solution$R)), zlim=c(0,max(solution$Z)), xlab=expression(S), ylab=expression(R), zlab=expression(Z), main="Phase Plot", highlight.3d=TRUE)
	if (params$zombie0PDF==TRUE) { 
		print("Plotted to file 'zombie0.pdf'.")
		dev.off()
	}
}

showEqn_zombie0 <- function() {
	createWin("eqnZombieBasic.win")
}

reset_default_params_zombie0_GUI <- function() {
	setWinVal(c(zombie0alpha=0.005, zombie0beta=0.0095, zombie0delta=0.001, zombie0Pi=0, zombie0zeta=0.001, zombie0Tmax=10, zombie0S0=1000, zombie0Z0=0, zombie0R0=0), "mainWinDisease")
}

# zombie infection model (latent infection) -- from Munz et al. (2009)
zombie1 <- function(t, popn, params) {
	with(as.list(c(popn, params)), {
		dS = Pi - beta * S * Z - delta * S
		dI = beta * S * Z - rho * I - delta * I
		dZ = rho * I + zeta * R - alpha * S * Z
		dR = delta * (S+I) + alpha * S * Z - zeta * R
		return(list(c(dS,dI,dZ,dR)))
	})
}

solve_zombie1_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	params <- list(alpha=params_GUI$zombie1alpha, beta=params_GUI$zombie1beta, delta=params_GUI$zombie1delta, Pi=params_GUI$zombie1Pi, rho=params_GUI$zombie1rho, zeta=params_GUI$zombie1zeta)
	popn <- c(S=params_GUI$zombie1S0, I=params_GUI$zombie1I0, Z=params_GUI$zombie1Z0, R=params_GUI$zombie1R0)
	time <-seq(0, params_GUI$zombie1Tmax, by=0.01)
	x <- as.data.frame( ode(func=zombie1, y=popn, parms=params, times=time) )
	print("Ready to plot.")
	return(x)
}

plot_zombie1_GUI <- function(solution) {	
	params <- getWinVal(scope="L");
	if (params$zombie1PDF==TRUE) { pdf("zombie1.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	# plot N vs t
	plot(S ~ time, data=solution, type="l", lty=1, lwd=2, ylim=c(0,1.5*max(S,I,Z,R)), xlab="Time (t)", ylab="Number of Individuals (S,I,Z,R)", main="A zombie infection model with latent infection", col="blue")
	points(I ~ time, data=solution, type="l", lty=4, lwd=2, col="orange")
	points(Z ~ time, data=solution, type="l", lty=2, lwd=2, col="darkred")
	points(R ~ time, data=solution, type="l", lty=3, lwd=2, col="darkgreen")
	legend("topright", c("S", "I", "Z","R"), lty=c(1,4,2,3), lwd=2, col=c("blue","orange","darkred","darkgreen"), box.lwd=0)
	# blank plots
	plot.new()
	plot.new()
	if (params$zombie1PDF==TRUE) { 
		print("Plotted to file 'zombie1.pdf'.")
		dev.off()
	}
}

showEqn_zombie1 <- function() {
	createWin("eqnZombieLatent.win")
}

reset_default_params_zombie1_GUI <- function() {
	setWinVal(c(zombie1alpha=0.005, zombie1beta=0.0095, zombie1delta=0.0001, zombie1Pi=0, zombie1rho=0.005, zombie1zeta=0.0001, zombie1Tmax=10, zombie1S0=1000, zombie1I0=0, zombie1Z0=0, zombie1R0=0), "mainWinDisease")
}

# zombie infection model (latent infection with quarantine) -- from Munz et al. (2009)
zombie2 <- function(t, popn, params) {
	with(as.list(c(popn, params)), {
		dS = Pi - beta * S * Z - delta * S
		dI = beta * S * Z - (rho + delta + kappa) * I
		dZ = rho * I + zeta * R - alpha * S * Z - sigma * Z
		dR = delta * (S+I) + alpha * S * Z - zeta * R + gamma * Q
		dQ = kappa * I + sigma * Z - gamma * Q
		return(list(c(dS,dI,dZ,dR,dQ)))
	})
}

solve_zombie2_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	params <- list(alpha=params_GUI$zombie2alpha, beta=params_GUI$zombie2beta, gamma=params_GUI$zombie2gamma, delta=params_GUI$zombie2delta, kappa=params_GUI$zombie2kappa, Pi=params_GUI$zombie2Pi, rho=params_GUI$zombie2rho, sigma=params_GUI$zombie2sigma, zeta=params_GUI$zombie2zeta)
	popn <- c(S=params_GUI$zombie2S0, I=params_GUI$zombie2I0, Z=params_GUI$zombie2Z0, R=params_GUI$zombie2R0, Q=params_GUI$zombie2Q0)
	time <-seq(0, params_GUI$zombie2Tmax, by=0.01)
	x <- as.data.frame( ode(func=zombie2, y=popn, parms=params, times=time) )
	print("Ready to plot.")
	return(x)
}

plot_zombie2_GUI <- function(solution) {	
	params <- getWinVal(scope="L");
	if (params$zombie2PDF==TRUE) { pdf("zombie2.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	# plot N vs t
	plot(S ~ time, data=solution, type="l", lty=1, lwd=2, ylim=c(0,1.5*max(S,I,Z,R,Q)), xlab="Time (t)", ylab="Number of Individuals (S,I,Z,R,Q)", main="A zombie infection model with quarantine", col="blue")
	points(I ~ time, data=solution, type="l", lty=4, lwd=2, col="orange")
	points(Z ~ time, data=solution, type="l", lty=2, lwd=2, col="darkred")
	points(R ~ time, data=solution, type="l", lty=3, lwd=2, col="darkgreen")
	points(Q ~ time, data=solution, type="l", lty=5, lwd=2, col="purple")
	legend("topright", c("S", "I", "Z","R","Q"), lty=c(1,4,2,3,5), lwd=2, col=c("blue","orange","darkred","darkgreen","purple"), box.lwd=0)
	# blank plots
	plot.new()
	plot.new()
	if (params$zombie2PDF==TRUE) { 
		print("Plotted to file 'zombie2.pdf'.")
		dev.off()
	}
}

showEqn_zombie2 <- function() {
	createWin("eqnZombieQuarantine.win")
}

reset_default_params_zombie2_GUI <- function() {
	setWinVal(c(zombie2alpha=0.005, zombie2beta=0.0095, zombie2gamma=0.01, zombie2delta=0.0001, zombie2kappa=0.01, zombie2Pi=0, zombie2rho=0.005, zombie2sigma=0.01, zombie2zeta=0.0001, zombie2Tmax=10, zombie2S0=1000, zombie2I0=0, zombie2Z0=0, zombie2R0=0, zombie2Q0=0), "mainWinDisease")
}

# zombie infection model (latent infection with cure/treatment) -- from Munz et al. (2009)
zombie3 <- function(t, popn, params) {
	with(as.list(c(popn, params)), {
		dS = Pi - beta * S * Z - delta * S + c * Z
		dI = beta * S * Z - (rho + delta) * I
		dZ = rho * I + zeta * R - alpha * S * Z - c * Z
		dR = delta * (S+I) + alpha * S * Z - zeta * R
		return(list(c(dS,dI,dZ,dR)))
	})
}

solve_zombie3_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	params <- list(alpha=params_GUI$zombie3alpha, beta=params_GUI$zombie3beta, c=params_GUI$zombie3c, delta=params_GUI$zombie3delta, Pi=params_GUI$zombie3Pi, rho=params_GUI$zombie3rho, zeta=params_GUI$zombie3zeta)
	popn <- c(S=params_GUI$zombie3S0, I=params_GUI$zombie3I0, Z=params_GUI$zombie3Z0, R=params_GUI$zombie3R0)
	time <-seq(0, params_GUI$zombie3Tmax, by=0.01)
	x <- as.data.frame( ode(func=zombie3, y=popn, parms=params, times=time) )
	print("Ready to plot.")
	return(x)
}

plot_zombie3_GUI <- function(solution) {	
	params <- getWinVal(scope="L");
	if (params$zombie3PDF==TRUE) { pdf("zombie3.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	# plot N vs t
	plot(S ~ time, data=solution, type="l", lty=1, lwd=2, ylim=c(0,1.5*max(S,I,Z,R)), xlab="Time (t)", ylab="Number of Individuals (S,I,Z,R)", main="A zombie infection model with quarantine", col="blue")
	points(I ~ time, data=solution, type="l", lty=4, lwd=2, col="orange")
	points(Z ~ time, data=solution, type="l", lty=2, lwd=2, col="darkred")
	points(R ~ time, data=solution, type="l", lty=3, lwd=2, col="darkgreen")
	legend("topright", c("S", "I", "Z","R"), lty=c(1,4,2,3), lwd=2, col=c("blue","orange","darkred","darkgreen"), box.lwd=0)
	# blank plots
	plot.new()
	plot.new()
	if (params$zombie3PDF==TRUE) { 
		print("Plotted to file 'zombie3.pdf'.")
		dev.off()
	}
}

showEqn_zombie3 <- function() {
	createWin("eqnZombieCure.win")
}

reset_default_params_zombie3_GUI <- function() {
	setWinVal(c(zombie3alpha=0.005, zombie3beta=0.0095, zombie3c=0.01, zombie3delta=0.0001, zombie3Pi=0, zombie3rho=0.005, zombie3zeta=0.0001, zombie3Tmax=10, zombie3S0=1000, zombie3I0=0, zombie3Z0=0, zombie3R0=0), "mainWinDisease")
}



createWin("407.disease.models.win")

