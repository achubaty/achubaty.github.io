#*******************************************
#** BISC 407: POPULATION DYNAMICS        ***
#** NUMERICAL APPROX. TECHNIQUES [GUI]   ***
#** Alex M. Chubaty 2011                 ***
#*******************************************

if (!require(PBSmodelling)) {
	install.packages("PBSmodelling");
}

if (!require(deSolve)) {
	install.packages("deSolve");
}

require(PBSmodelling);
require(deSolve);

clearAll();

# our function: y'(x) = exp(x) which means y(x) = exp(x)
dy.dx <- function (x) {
	return ( exp(x) )
}

# Euler method
plot_euler <- function (params) {	
	x <- numeric((params$b-params$a)/params$h+1)
	y <- numeric(length(x))
	x[1] <- params$x0
	y[1] <- dy.dx(params$x0)
	for (i in 1:length(x)) {
		# add first point (x0,y0)
		points(x[i],y[i],pch=20,cex=2,col="blue")
#		text(x[i]+0.05,y[i]-3,sprintf("(x%d,y%d)",i-1,i-1))
		k1 <- params$h * dy.dx( x[i] )
		x[i+1] <- x[i] + params$h
		y[i+1] <- y[i] + k1
		# draw slope at this point
		segments(x[i],y[i],x[i+1],y[i+1],col="blue",lwd=2)
	}
}

# midpoint method
plot_midpoint <- function (params) {	
	x <- numeric((params$b-params$a)/params$h+1)
	y <- numeric(length(x))
	x[1] <- params$x0
	y[1] <- dy.dx(params$x0)
	for (i in 1:length(x)) {
		# add first point (x0,y0)
		points(x[i],y[i],pch=20,cex=2,col="darkgreen")
#		text(x[i]+0.05,y[i]-3,sprintf("(x%d,y%d)",i-1,i-1))
		k1 <- params$h * dy.dx( x[i] )
		k2 <- params$h * dy.dx( x[i] + params$h/2 )
		x[i+1] <- x[i] + params$h
		y[i+1] <- y[i] + k2
		# draw slope at this point
		segments(x[i],y[i],x[i+1],y[i+1],col="darkgreen",lwd=2)
	}
}

# 4th order Runge-Kutta method
plot_RK4 <- function (params) {	
	x <- numeric((params$b-params$a)/params$h+1)
	y <- numeric(length(x))
	x[1] <- params$x0
	y[1] <- dy.dx(params$x0)
	for (i in 1:length(x)) {
		# add first point (x0,y0)
		points(x[i],y[i],pch=20,cex=2,col="darkred")
#		text(x[i]+0.05,y[i]-3,sprintf("(x%d,y%d)",i-1,i-1))
		k1 <- params$h * dy.dx( x[i] )
		k2 <- params$h * dy.dx( x[i] + params$h/2 )
		k3 <- params$h * dy.dx( x[i] + params$h/2 )
		k4 <- params$h * dy.dx( x[i] + params$h )
		x[i+1] <- x[i] + params$h
		y[i+1] <- y[i] + (1/6) * (k1 + 2*k2 + 2*k3 + k4)
		# draw slope at this point
		segments(x[i],y[i],x[i+1],y[i+1],col="darkred",lwd=2)
	}
}




# main plot function
plot_numapprox_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	params <- list(a=params_GUI$numapproxa, b=params_GUI$numapproxb, h=params_GUI$numapproxh, x0=params_GUI$numapproxx0)

	par(mar=c(5,5,1,1))
	curve( dy.dx(x), lwd=3, xlim=c(params$a,params$b), ylim=c(-5,60), xlab=expression(x), ylab=expression(y(x)), cex.lab=2 )
	if (params_GUI$numapproxEuler==TRUE) { plot_euler(params) }
	if (params_GUI$numapproxMidpoint==TRUE) { plot_midpoint(params) }
	if (params_GUI$numapproxRK4==TRUE) { plot_RK4(params) }
	legend("topleft", legend=c("exact solution","Euler method","midpoint method","4th order Runge-Kutta"), col=c("black","blue","darkred","darkgreen"), lty=1, lwd=3)
}

reset_default_params_numapprox_GUI <- function() {
	setWinVal(c(numapproxa=0, numapproxb=4, numapproxh=1, numapproxx0=0), "mainWinNumApprox")
}



createWin("407.num.approx.win")

