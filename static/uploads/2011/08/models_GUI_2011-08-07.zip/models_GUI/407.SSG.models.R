#*******************************************
#** BISC 407: POPULATION DYNAMICS        ***
#** SINGLE SPECIES GROWTH MODELS [GUI]   ***
#** Alex M. Chubaty 2011                 ***
#*******************************************

if (!require(PBSmodelling)) {
	install.packages("PBSmodelling");
}

if (!require(deSolve)) {
	install.packages("deSolve");
}

require(PBSmodelling);
require(deSolve);

clearAll();

# exponential stuff (discrete and continuous forms)
dN_exp <- function(N, r=0.5) {
	return ( r * N )
}

exponential_c <- function(t, popn, params) {
	with(as.list(c(popn, params)), {
		DN = dN_exp(N,r)
		return(list(DN))
	})
}

exponential_d <- function(N0, Tmax, lambda) {
	x <- array( data=NA, dim=c(Tmax+1,2), dimnames=list(NULL,c("t","Nt")) )	# prepare array to store data
	x[,1] <- 0:Tmax				# fill in 't' values in first column
	x[1,2] <- N0				# set initial population size to N0
	for(t in 1:Tmax){			# loop to calculate Nt+1 at each time step
		x[t+1,2] <- lambda * x[t,2]
	}
	return(x)				# return the array
}

solve_exponential_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	if (exptype==0) {
		params <- c(r=params_GUI$expr)
		popn <- c(N=params_GUI$expN0)
		time <- seq(0, 20, by=0.1)
		x <- as.data.frame( ode(func=exponential_c, y=popn, parms=params, times=time) )
	}
	else if (exptype==1) {
		x <- exponential_d(params_GUI$expN0, params_GUI$expTmax, params_GUI$explambda)
	}
	else {  }
	print("Ready to plot.")
	return(x)
}

plot_cobweb_exponential <- function(tNt, cobweb=FALSE) {
	NMAX <- max(tNt[,2])*1.2 # Prepare the plotting area
	plot(NULL, NULL, xlim=c(0,NMAX), ylim=c(0,NMAX), xlab=expression(N[t]), ylab=expression(N[t+1]), main="Cobweb Diagram")
	N1 <- tNt[-nrow(tNt),2]	# Nt: population sizes excluding last time step
	N2 <- tNt[-1,2]		# Nt+1: population sizes excluding first time step
	points( N1[order(N1)], N2[order(N1)], type="l", lwd=2 )
	abline(a=0,b=1,lty=3,lwd=2,col="red")	# add the line: Nt = Nt+1
	
	if (cobweb==TRUE) {
		# Trace population changes
		arrows( x0=N1, y0=N1, x1=N1, y1=N2, length=0.075, col="grey" )	# vertical lines
		arrows( x0=N1, y0=N2, x1=N2, y1=N2, length=0.075, col="grey" )	# horizontal lines
	}	  
}

plot_exponential_GUI <- function(TNT) {
	params <- getWinVal(scope="L");
	if (params$expPDF==TRUE) { pdf("exponential.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	if (exptype==0) {
		plot( N ~ time, data=TNT, type="l", ylim=c(0,1.2*max(TNT[,-1])), xlab="Time (t)", ylab="Population Size (N)", main="Exponential population growth", col="blue", lwd=2 )
		plot.new()
		plot.new()
	}
	else if (exptype==1) {
		plot( TNT, pch=20, type="b", xlab="Generation, t", ylab=expression(N[t]), main="Exponential population growth", col="blue", lwd=2 )
		plot.new()
		plot_cobweb_exponential(TNT,params$expcobweb)
	}
	else { plot.new() }
	if (params$expPDF==TRUE) { 
		print("Plotted to file 'exponential.pdf'.")
		dev.off()
	}
}

showEqn_exponential <- function() {
	createWin("eqnExponential.win")
}

reset_default_params_exponential_GUI <- function() {
	setWinVal(c(expr=0.5, explambda=1.5, expN0=0.1, expTmax=20), "mainWinSSG")
}

# basic logistic stuff
dN_logistic <- function(N, r=1.86, K=700) {
	return ( r * N * ( 1 - N/K ) )
}

logistic_c <- function(t, popn, params) {
	with(as.list(c(popn, params)), {
		dN = r * N * ( 1 - N/K )
		return(list(dN))
	})
}

logistic_d <- function(N0, Tmax, rd, K) {
	x <- array( data=NA, dim=c(Tmax+1,2), dimnames=list(NULL,c("t","Nt")) )	# prepare array to store data
	x[,1] <- 0:Tmax				# fill in 't' values in first column
	x[1,2] <- N0				# set initial population size to N0
	for(t in 1:Tmax){			# loop to calculate Nt+1 at each time step
		x[t+1,2] <- x[t,2] + rd * x[t,2] * ( 1 - x[t,2] / K )
	}
	return(x)				# return the array
}

solve_logistic_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	if (logtype==0) {
		params <- c(r=params_GUI$logr, K=params_GUI$logK)
		popn <- c(N=params_GUI$logN0)
		time <- seq(0, params_GUI$logTmax, by=0.01)
		x <- as.data.frame( ode(func=logistic_c, y=popn, parms=params, times=time) )
	}
	else if (logtype==1) {
		x <- logistic_d(params_GUI$logN0, params_GUI$logTmax, params_GUI$logrd, params_GUI$logK)
	}
	else {}
	print("Ready to plot.")
	return(x)
}

plot_cobweb_logistic <- function(tNt, cobweb=FALSE) {
	NMAX <- max(tNt[,2])*1.2 # Prepare the plotting area
	plot( NULL, NULL, xlim=c(0,NMAX), ylim=c(0,NMAX), xlab=expression(N[t]), ylab=expression(N[t+1]), main="Cobweb Diagram", lwd=2 )
	N1 <- tNt[-nrow(tNt),2]	# Nt: population sizes excluding last time step
	N2 <- tNt[-1,2]		# Nt+1: population sizes excluding first time step
	points( N1[order(N1)], N2[order(N1)], type="l", lwd=2 )
	abline(a=0,b=1,lty=3,lwd=2,col="red")	# add the line: Nt = Nt+1
	
	if (cobweb==TRUE) {
		# Trace population changes
		arrows( x0=N1, y0=N1, x1=N1, y1=N2, length=0.075, col="grey" )	# vertical lines
		arrows( x0=N1, y0=N2, x1=N2, y1=N2, length=0.075, col="grey" )	# horizontal lines
	}	  
}

plot_logistic_GUI <- function(solution) {	
	params <- getWinVal(scope="L");
	if (params$logPDF==TRUE) { pdf("logistic.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	if (logtype==0) {
		plot(solution, type="l", ylim=c(0,1.2*max(solution[,-1])), xlab="Time (t)", ylab="Population Size (N)", main="Logistic population growth", col="blue", lwd=2)
		curve( dN_logistic(x,params$logr,params$logK), xlim=c(0,1.2*params$logK), xlab="Population size (N)", ylab=expression(dN/dt), main="Population productivity", col="red", lwd=2 )
		abline(h=0, lty=3, lwd=2)
		curve( dN_logistic(x,params$logr,params$logK)/x, xlim=c(0,1.2*params$logK), xlab="Population size (N)", ylab=expression((1/N)*(dN/dt)), main="Per-capita productivity", col="darkgreen", lwd=2 )
		abline(h=0, lty=3, lwd=2)
	}
	else if (logtype==1) {
		plot( solution, pch=20, type="b", xlab="Generation, t", ylab=expression(N[t]), main="Exponential population growth", col="blue", lwd=2 )
		plot.new()
		plot_cobweb_logistic(solution,params$logcobweb)
	}
	else {
		plot.new()
		plot.new()
		plot.new()
		plot.new()
	}
	if (params$logPDF==TRUE) { 
		print("Plotted to file 'logistic.pdf'.")
		dev.off()
	}
}

showEqn_logistic <- function() {
	createWin("eqnLogistic.win")
}

reset_default_params_logistic_GUI <- function() {
	setWinVal(c(logr=1.86, logK=700, logN0=0.1, logTmax=20, logrd=1.5), "mainWinSSG")
}

# lag-logistic stuff
dN_lag_logistic <- function(t, N, params) {
	params <- as.data.frame( t(params) )
	if (t<params$tau) { dN <- params$r * N * ( 1 -  N/params$K )	}
	else { dN <- params$r * N * ( 1 -  lagvalue(t-params$tau)/params$K ) }
	return ( list(c(dN)) )
}

lag_logistic_d <- function(N0, Tmax, lambda, K, deltat) {
	x <- array( data=NA, dim=c(Tmax+1,2), dimnames=list(NULL,c("t","Nt")) )	# prepare array to store data
	x[,1] <- 0:Tmax				# fill in 't' values in first column
	x[1,2] <- N0				# set initial population size to N0
	for(t in 1:Tmax){			# loop to calculate Nt+1 at each time step
		# using the hassell derivation as per the beverton-holt model
		if (t<=deltat) { x[t+1,2] <- ( lambda * x[t,2] ) / ( 1 + (lambda - 1)/K * x[t,2] ) } # solve as if no timelag, when t<=timelag
		else {	x[t+1,2] <- ( lambda * x[t,2] ) / ( 1 + (lambda - 1)/K * x[t-deltat,2] ) } # solve with time lag

	}
	return(x)				# return the array
}

solve_lag_logistic_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	if (log2type==0) {
		params <- c(r=params_GUI$log2r, K=params_GUI$log2K, tau=params_GUI$log2tau)
		popn <- c(N=params_GUI$log2N0)
		time <- seq(0, params_GUI$log2Tmax, by=0.001)
		print("Solving...")
		x <- as.data.frame( dede(func=dN_lag_logistic, y=popn, parms=params, times=time) )
	}
	else if (log2type==1) {
		x <- lag_logistic_d(params_GUI$log2N0, params_GUI$log2Tmax, params_GUI$log2lambda, params_GUI$log2K, params_GUI$log2deltat)
	}
	else {}
	print("Ready to plot.")
	return(x)
}

plot_lag_logistic_GUI <- function(solution) {	
	params <- getWinVal(scope="L");
	if (params$log2PDF==TRUE) { pdf("lag-logistic.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	if (log2type==0) {
		plot( solution, type="l", ylim=c(0,1.2*max(solution[,-1])), xlab="Time (t)", ylab="Population Size (N)", main="Lag-logistic population growth", col="blue", lwd=2 )
	}
	else if (log2type==1) {
		plot( solution, pch=20, type="b", xlab="Generation, t", ylab=expression(N[t]), main="Lag-Logistic population growth", col="blue", lwd=2 )
	}
	else {
		plot.new()
	}
	if (params$log2PDF==TRUE) { 
		print("Plotted to file 'lag-logistic.pdf'.")
		dev.off()
	}
}

showEqn_lag_logistic <- function() {
	createWin("eqnLagLogistic.win")
}

reset_default_params_lag_logistic_GUI <- function() {
	setWinVal(c(log2r=1.86, log2K=700, log2tau=1, log2N0=0.1, log2Tmax=20, log2lambda=2.86, log2deltat=2), "mainWinSSG")
}

# theta-logistic stuff
dN_theta_logistic <- function(N, r=1.86, K=700, theta=1.5) {
	return ( r * N * ( 1 - (N/K)^theta ) )
}

theta_logistic <- function(t, popn, params) {
	with(as.list(c(popn, params)), {
		dN = r * N * ( 1 - (N/K)^theta )
		return(list(dN))
	})
}

solve_theta_logistic_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	params <- c(r=params_GUI$log3r, K=params_GUI$log3K, theta=params_GUI$log3theta)
	popn <- c(N=params_GUI$log3N0)
	time <-seq(0, params_GUI$log3Tmax, by=0.01)
	x <- as.data.frame( ode(func=theta_logistic, y=popn, parms=params, times=time) )
	print("Ready to plot.")
	return(x)
}

max_pp_theta_logistic <- function(K, theta) {
	return ( K * ( 1 / (1+theta) ) ^ (1/theta) )
}

plot_theta_logistic_GUI <- function(solution) {	
	params <- getWinVal(scope="L");
	if (params$log3PDF==TRUE) { pdf("theta-logistic.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	plot( solution, type="l", ylim=c(0,1.2*max(solution[,-1])), xlab="Time (t)", ylab="Population Size (N)", main="Theta-logistic population growth", col="blue", lwd=2 )
	curve( dN_theta_logistic(x,params$log3r,params$log3K,params$log3theta), xlim=c(0,1.2*params$log3K), xlab="Population size (N)", ylab=expression(dN/dt), main="Population productivity", col="red", lwd=2 )
	abline(v=max_pp_theta_logistic(params$log3K,params$log3theta), lty=2, lwd=2, col="red")
	abline(h=0, lty=3, lwd=2)
	curve( dN_theta_logistic(x,params$log3r,params$log3K,params$log3theta)/x, xlim=c(0,1.2*params$log3K), xlab="Population size (N)", ylab=expression((1/N)*(dN/dt)), main="Per-capita productivity", col="darkgreen", lwd=2 )
	abline(h=0, lty=3, lwd=2)
	if (params$log3PDF==TRUE) { 
		print("Plotted to file 'theta-logistic.pdf'.")
		dev.off()
	}
}

showEqn_theta_logistic <- function() {
	createWin("eqnThetaLogistic.win")
}

reset_default_params_theta_logistic_GUI <- function() {
	setWinVal(c(log3r=1.86, log3K=700, log3theta=1.5, log3N0=0.1, log3Tmax=20), "mainWinSSG")
}

# Random-K logistic stuff
randK_logistic <- function(N0, Tmax, rd, K0, sigma) {
	x <- array( data=NA, dim=c(Tmax+1,3), dimnames=list(NULL,c("t","Nt","Kt")) )	# prepare array to store data
	x[,1] <- 0:Tmax				# fill in 't' values in first column
	x[1,2] <- N0				# set initial population size to N0
	x[,3] <- rnorm(Tmax+1, K0, sigma)		# random carrying capacities following normal distribution mean=K0, sd=sigma
	x[1,3] <- K0				# set initial carrying capacity to K0
	for(t in 1:Tmax){			# loop to calculate Nt+1 at each time step
		x[t+1,2] <- x[t,2] + rd * x[t,2] * ( 1 - x[t,2] / x[t,3] )
	}
	return(x)				# return the array
}

solve_randK_logistic_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	x <- randK_logistic(params_GUI$log4N0, params_GUI$log4Tmax, params_GUI$log4rd, params_GUI$log4K0, params_GUI$log4sigma)
	print("Ready to plot.")
	return(x)
}

plot_randK_logistic_GUI <- function(solution) {	
	params <- getWinVal(scope="L");
	if (params$log4PDF==TRUE) { pdf("randK_logistic.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	plot( solution, pch=20, type="b", xlab="Generation, t", ylab=expression(N[t]), main="Random-K logistic population growth", col="blue", lwd=2 )
	plot.new()
	plot.new()
	if (params$logPDF==TRUE) { 
		print("Plotted to file 'randK_logistic.pdf'.")
		dev.off()
	}
}

showEqn_randK_logistic <- function() {
	createWin("eqnRandKLogistic.win")
}

reset_default_params_randK_logistic_GUI <- function() {
	setWinVal(c(log4rd=1.86, log4K0=700, log4sigma=42, log4N0=1, logTmax=40), "mainWinSSG")
}

# Allee logistic stuff
dN_logistic_allee <- function(N, r, K, M) {
	return ( r * N * ( 1 - N/K ) * ( 1 - M/N ) )
}

logistic_allee <- function(t, popn, params) {
	with(as.list(c(popn, params)), {
		dN = r * N * ( 1 - N/K ) * ( 1 - M/N )
		return(list(dN))
	})
}

solve_logistic_allee_GUI <- function() {
	params_GUI <- getWinVal(scope="L");
	params <- c(r=params_GUI$log5r, K=params_GUI$log5K, M=params_GUI$log5M)
	popn <- c(N=params_GUI$log5N0)
	time <- seq(0, params_GUI$log5Tmax, by=0.01)
	x <- as.data.frame( ode(func=logistic_allee, y=popn, parms=params, times=time) )
	print("Ready to plot.")
	return(x)
}

max_pp_logistic_allee <- function(K, M) {
	return ( (K+M)/2 )
}


plot_logistic_allee_GUI <- function(solution) {	
	params <- getWinVal(scope="L");
	if (params$log5PDF==TRUE) { pdf("logistic_allee.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	plot( solution, type="l", ylim=c(0,1.2*max(solution[,-1])), xlab="Time (t)", ylab="Population Size (N)", main="IDD-Logistic population growth", col="blue", lwd=2 )
	curve( dN_logistic_allee(x,params$logr,params$log5K,params$log5M), xlim=c(0,1.2*params$log5K), xlab="Population size (N)", ylab=expression(dN/dt), main="Population productivity", col="red", lwd=2)
	abline(v=max_pp_logistic_allee(params$log5K,params$log5M), lty=2, col="red", lwd=2)
	abline(h=0, lty=3, lwd=2)
	curve( dN_logistic_allee(x,params$logr,params$log5K,params$log5M)/x, xlim=c(0,1.2*params$log5K), xlab="Population size (N)", ylab=expression((1/N)*(dN/dt)), main="Per-capita productivity", col="darkgreen", lwd=2 )
	abline(h=0, lty=3, lwd=2)
	if (params$logPDF==TRUE) { 
		print("Plotted to file 'logistic_allee.pdf'.")
		dev.off()
	}
}

showEqn_logistic_allee <- function() {
	createWin("eqnLogisticAllee.win")
}

reset_default_params_logistic_allee_GUI <- function() {
	setWinVal(c(log5r=1.86, log5K=700, log5M=50, log5N0=51, log5Tmax=20), "mainWinSSG")
}



# Ricker1 stuff
ricker1 <- function(N0, Tmax, rd, K) {
	x <- array( data=NA, dim=c(Tmax+1,2), dimnames=list(NULL,c("t","Nt")) )	# prepare array to store data
	x[,1] <- 0:Tmax				# fill in 't' values in first column
	x[1,2] <- N0				# set initial population size to N0
	for(t in 1:Tmax){			# loop to calculate Nt+1 at each time step
		x[t+1,2] <- x[t,2] * exp(rd*(1-x[t,2]/K))
	}
	return(x)				# return the array
}

solve_ricker1_GUI <- function() {
	params <- getWinVal(scope="L");
	x <- ricker1(params$rick1N0, params$rick1Tmax, params$rick1rd, params$rick1K)
	print("Ready to plot.")
	return(x)
}

plot_cobweb_ricker1 <- function(tNt, cobweb=FALSE) {
	NMAX <- max(tNt[,2])*1.2 # Prepare the plotting area
	plot(NULL, NULL, xlim=c(0,NMAX), ylim=c(0,NMAX), xlab=expression(N[t]), ylab=expression(N[t+1]), main="Cobweb Diagram")
	N1 <- tNt[-nrow(tNt),2]	# Nt: population sizes excluding last time step
	N2 <- tNt[-1,2]		# Nt+1: population sizes excluding first time step
	points( N1[order(N1)], N2[order(N1)], type="l", lwd=2 )
	abline(a=0,b=1,lty=3,lwd=2,col="red")	# add the line: Nt = Nt+1
	
	if (cobweb==TRUE) {
		# Trace population changes
		arrows( x0=N1, y0=N1, x1=N1, y1=N2, length=0.075, col="grey" )	# vertical lines
		arrows( x0=N1, y0=N2, x1=N2, y1=N2, length=0.075, col="grey" )	# horizontal lines
	}	  
}

plot_ricker1_GUI <- function(TNT) {
	params <- getWinVal(scope="L");
	if (params$rick1PDF==TRUE) { pdf("ricker1.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	plot( TNT, pch=20, type="b", xlab="Generation, t", ylab=expression(N[t]), main="Ricker Model", lwd=2 )
	plot.new()
	plot_cobweb_ricker1(TNT,params$rick1cobweb)
	if (params$rick1PDF==TRUE) { 
		print("Plotted to file 'ricker1.pdf'.")
		dev.off()
	}
}

showEqn_ricker <- function() {
	createWin("eqnRicker.win")
}

reset_default_params_ricker1_GUI <- function() {
	setWinVal(c(rick1rd=1.86, rick1K=700, rick1N0=1, rick1Tmax=40), "mainWinSSG")
}

# Ricker2 stuff
ricker2 <- function(N0, Tmax, lambda, K, b) {
	x <- array( data=NA, dim=c(Tmax+1,2), dimnames=list(NULL,c("t","Nt")) )	# prepare array to store data
	x[,1] <- 0:Tmax				# fill in 't' values in first column
	x[1,2] <- N0				# set initial population size to N0
	for(t in 1:Tmax){			# loop to calculate Nt+1 at each time step
		x[t+1,2] <- lambda * x[t,2] / (1 + (lambda-1)/K * x[t,2])^b
	}
	return(x)				# return the array
}

solve_ricker2_GUI <- function() {
	params <- getWinVal(scope="L");
	x <- ricker2(params$rick2N0, params$rick2Tmax, params$rick2lambda, params$rick2K, params$rick2b)
	print("Ready to plot.")
	return(x)
}

plot_cobweb_ricker2 <- function(tNt, cobweb=FALSE) {
	NMAX <- max(tNt[,2])*1.2 # Prepare the plotting area
	plot(NULL, NULL, xlim=c(0,NMAX), ylim=c(0,NMAX), xlab=expression(N[t]), ylab=expression(N[t+1]), main="Cobweb Diagram")
	N1 <- tNt[-nrow(tNt),2]	# Nt: population sizes excluding last time step
	N2 <- tNt[-1,2]		# Nt+1: population sizes excluding first time step
	points( N1[order(N1)], N2[order(N1)], type="l", lwd=2 )
	abline(a=0,b=1,lty=3,lwd=2,col="red")	# add the line: Nt = Nt+1
	
	if (cobweb==TRUE) {
		# Trace population changes
		arrows( x0=N1, y0=N1, x1=N1, y1=N2, length=0.075, col="grey" )	# vertical lines
		arrows( x0=N1, y0=N2, x1=N2, y1=N2, length=0.075, col="grey" )	# horizontal lines
	}	  
}

plot_ricker2_GUI <- function(TNT) {
	params <- getWinVal(scope="L");
	if (params$rick2PDF==TRUE) { pdf("ricker2.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	plot( TNT, pch=20, type="b", xlab="Generation, t", ylab=expression(N[t]), main="Alternate Ricker Model", lwd=2 )
	plot.new()
	plot_cobweb_ricker2(TNT,params$rick2cobweb)
	if (params$rick2PDF==TRUE) { 
		print("Plotted to file 'ricker2.pdf'.")
		dev.off()
	}
}

reset_default_params_ricker2_GUI <- function() {
	setWinVal(c(rick2lambda=2.36, rick2K=700, rick2b=1.5, rick2N0=1, rick2Tmax=40), "mainWinSSG")
}

# Ricker3 (Salmon) stuff
ricker3 <- function(N0, Tmax, phi, lts, delta, Tc) {
	x <- array( data=NA, dim=c(Tmax+1,2), dimnames=list(NULL,c("t","Nt")) )	# prepare array to store data
	x[,1] <- 0:Tmax				# fill in 't' values in first column
	x[1,2] <- N0				# set initial population size to N0
	for(t in 1:Tmax){			# loop to calculate Nt+1 at each time step
		x[t+1,2] <- phi * x[t,2] * lts * exp(-delta*Tc*x[t,2])
	}
	return(x)				# return the array
}

solve_ricker3_GUI <- function() {
	params <- getWinVal(scope="L");
	x <- ricker3(params$rick3N0, params$rick3Tmax, params$rick3phi, params$rick3lts, params$rick3delta, params$rick3Tc)
	print("Ready to plot.")
	return(x)
}

plot_cobweb_ricker3 <- function(tNt, cobweb=FALSE) {
	NMAX <- max(tNt[,2])*1.2 # Prepare the plotting area
	plot(NULL, NULL, xlim=c(0,NMAX), ylim=c(0,NMAX), xlab=expression(N[t]), ylab=expression(N[t+1]), main="Cobweb Diagram")
	N1 <- tNt[-nrow(tNt),2]	# Nt: population sizes excluding last time step
	N2 <- tNt[-1,2]		# Nt+1: population sizes excluding first time step
	points( N1[order(N1)], N2[order(N1)], type="l", lwd=2 )
	abline(a=0,b=1,lty=3,lwd=2,col="red")	# add the line: Nt = Nt+1
	
	if (cobweb==TRUE) {
		# Trace population changes
		arrows( x0=N1, y0=N1, x1=N1, y1=N2, length=0.075, col="grey" )	# vertical lines
		arrows( x0=N1, y0=N2, x1=N2, y1=N2, length=0.075, col="grey" )	# horizontal lines
	}	  
}

plot_ricker3_GUI <- function(TNT) {
	params <- getWinVal(scope="L");
	if (params$rick3PDF==TRUE) { pdf("ricker3.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	plot( TNT, pch=20, type="b", xlab="Generation, t", ylab=expression(N[t]), main="Ricker Salmon Model", lwd=2 )
	plot.new()
	plot_cobweb_ricker3(TNT,params$rick3cobweb)
	if (params$rick3PDF==TRUE) { 
		print("Plotted to file 'ricker3.pdf'.")
		dev.off()
	}
}

bifurc_ricker3_GUI <- function() {
	params <- getWinVal(scope="L");	
	if (rick3bifurctype==0) {
		# Run ricker function for each value of phi
		phi.values <- seq(0, 200, 0.1)
		for (i in 1:length(phi.values)) {
			if (i==1) {
				# on the first run, store values of 't' also
				tNt.bifurc <- ricker3(params$rick3N0, Tmax=200, phi=phi.values[i], params$rick3lts, params$rick3delta, params$rick3Tc)
			} else {
				# on following runs, store only 'Nt'
				x <- ricker3(params$rick3N0, Tmax=200, phi=phi.values[i], params$rick3lts, params$rick3delta, params$rick3Tc)[,2]
				tNt.bifurc <- cbind(tNt.bifurc, x)
			}
		}
	}
	if (rick3bifurctype==1) {
		# Run ricker function for each value of lts
		lts.values <- seq(0, 1, 0.001)
		for (i in 1:length(lts.values)) {
			if (i==1) {
				# on the first run, store values of 't' also
				tNt.bifurc <- ricker3(params$rick3N0, Tmax=200, params$rick3phi, lts=lts.values[i], params$rick3delta, params$rick3Tc)
			} else {
				# on following runs, store only 'Nt'
				x <- ricker3(params$rick3N0, Tmax=200, params$rick3phi, lts=lts.values[i], params$rick3delta, params$rick3Tc)[,2]
				tNt.bifurc <- cbind(tNt.bifurc, x)
			}
		}
	}
	if (rick3bifurctype==2) {
		# Run ricker function for each value of delta
		delta.values <- seq(0.0001, 0.01, 0.0001)
		for (i in 1:length(delta.values)) {
			if (i==1) {
				# on the first run, store values of 't' also
				tNt.bifurc <- ricker3(params$rick3N0, Tmax=200, params$rick3phi, params$rick3lts, delta=delta.values[i], params$rick3Tc)
			} else {
				# on following runs, store only 'Nt'
				x <- ricker3(params$rick3N0, Tmax=200, params$rick3phi, params$rick3lts, delta=delta.values[i], params$rick3Tc)[,2]
				tNt.bifurc <- cbind(tNt.bifurc, x)
			}
		}
	}
	if (rick3bifurctype==3) {
		# Run ricker function for each value of Tc
		Tc.values <- seq(1, 20, 1)
		for (i in 1:length(Tc.values)) {
			if (i==1) {
				# on the first run, store values of 't' also
				tNt.bifurc <- ricker3(params$rick3N0, Tmax=200, params$rick3phi, params$rick3lts, params$rick3delta, Tc=Tc.values[i])
			} else {
				# on following runs, store only 'Nt'
				x <- ricker3(params$rick3N0, Tmax=200, params$rick3phi, params$rick3lts, params$rick3delta, Tc=Tc.values[i])[,2]
				tNt.bifurc <- cbind(tNt.bifurc, x)
			}
		}
	}

	NMAX <- max(tNt.bifurc[,-1]) * 1.1
	
	if (rick3bifurctype==0) {
		if (params$rick3PDF==TRUE) { pdf("bifurc-ricker3-phi.pdf", height=5, width=10) }
		par(mar=c(5,5,1,1))
		plot(NULL, NULL, xlim=c(0,200), ylim=c(0,NMAX), xlab=expression(phi), ylab=expression(N[t]), cex.lab=1.5)
		for (i in 1:length(phi.values)) {
			# plot the last 50 values of Nt for each phi
			points( rep(phi.values[i],50), tNt.bifurc[151:200,i+1], pch=19, cex=0.2, col=hsv(h=1,s=1,v=0,alpha=0.2) )
		}
		if (params$rick3PDF==TRUE) { 
			print("Plotted to file 'bifurc-ricker3-phi.pdf'.")
			dev.off()
		}
	} else if (rick3bifurctype==1) {
		if (params$rick3PDF==TRUE) { pdf("bifurc-ricker3-lts.pdf", height=5, width=10) }
		par(mar=c(5,5,1,1))
		plot(NULL, NULL, xlim=c(0,1), ylim=c(0,NMAX), xlab=expression(l[ts]), ylab=expression(N[t]), cex.lab=1.5)
		for (i in 1:length(lts.values)) {
			# plot the last 50 values of Nt for each lts
			points( rep(lts.values[i],50), tNt.bifurc[151:200,i+1], pch=19, cex=0.2, col=hsv(h=1,s=1,v=0,alpha=0.2) )
		}
		if (params$rick3PDF==TRUE) { 
			print("Plotted to file 'bifurc-ricker3-lts.pdf'.")
			dev.off()
		}
	} else if (rick3bifurctype==2) {
		if (params$rick3PDF==TRUE) { pdf("bifurc-ricker3-delta.pdf", height=5, width=10) }
		par(mar=c(5,5,1,1))
		plot(NULL, NULL, xlim=c(0,0.01), ylim=c(0,NMAX), xlab=expression(delta), ylab=expression(N[t]), cex.lab=1.5)
		for (i in 1:length(delta.values)) {
			# plot the last 50 values of Nt for each delta
			points( rep(delta.values[i],50), tNt.bifurc[151:200,i+1], pch=19, cex=0.2, col=hsv(h=1,s=1,v=0,alpha=0.2) )
		}
		if (params$rick3PDF==TRUE) { 
			print("Plotted to file 'bifurc-ricker3-delta.pdf'.")
			dev.off()
		}
	} else if (rick3bifurctype==3) {
		if (params$rick3PDF==TRUE) { pdf("bifurc-ricker3-Tc.pdf", height=5, width=10) }
		par(mar=c(5,5,1,1))
		plot(NULL, NULL, xlim=c(0,20), ylim=c(0,NMAX), xlab=expression(T[c]), ylab=expression(N[t]), cex.lab=1.5)
		for (i in 1:length(Tc.values)) {
			# plot the last 50 values of Nt for each lts
			points( rep(Tc.values[i],50), tNt.bifurc[151:200,i+1], pch=19, cex=0.2, col=hsv(h=1,s=1,v=0,alpha=0.2) )
		}
		if (params$rick3PDF==TRUE) { 
			print("Plotted to file 'bifurc-ricker3-Tc.pdf'.")
			dev.off()
		}
	}
}

reset_default_params_ricker3_GUI <- function() {
	setWinVal(c(rick3phi=20, rick3lts=0.25, rick3delta=0.002, rick3Tc=8, rick3N0=1, rick3Tmax=40), "mainWinSSG")
}

# Growth-yield stuff
growth_yield <- function(N_i, Tmax, lambda, a, b, m) {
	x <- array( data=NA, dim=c(Tmax+1,2), dimnames=list(NULL,c("t","Nt")) )	# prepare array to store data
	x[,1] <- 0:Tmax				# fill in 't' values in first column
	x[1,2] <- N_i				# set initial population size to N0
	for(t in 1:Tmax){			# loop to calculate Nt+1 at each time step
		x[t+1,2] <- lambda * x[t,2] / (1 + a * N_i / ( 1 + m * N_i) )^b
	}
	return(x)				# return the array
}

solve_growth_yield_GUI <- function() {
	params <- getWinVal(scope="L");
	x <- growth_yield(params$gyNi, params$gyTmax, params$gylambda, params$gya, params$gyb, params$gym)
	print("Ready to plot.")
	return(x)
}

plot_cobweb_growth_yield <- function(tNt, cobweb=FALSE) {
	NMAX <- max(tNt[,2])*1.2 # Prepare the plotting area
	plot(NULL, NULL, xlim=c(0,NMAX), ylim=c(0,NMAX), xlab=expression(N[t]), ylab=expression(N[t+1]), main="Cobweb Diagram")
	N1 <- tNt[-nrow(tNt),2]	# Nt: population sizes excluding last time step
	N2 <- tNt[-1,2]		# Nt+1: population sizes excluding first time step
	points( N1[order(N1)], N2[order(N1)], type="l", lwd=2 )
	abline(a=0,b=1,lty=3,lwd=2,col="red")	# add the line: Nt = Nt+1
	
	if (cobweb==TRUE) {
		# Trace population changes
		arrows( x0=N1, y0=N1, x1=N1, y1=N2, length=0.075, col="grey" )	# vertical lines
		arrows( x0=N1, y0=N2, x1=N2, y1=N2, length=0.075, col="grey" )	# horizontal lines
	}	  
}

plot_growth_yield_GUI <- function(TNT) {
	params <- getWinVal(scope="L");
	if (params$gyPDF==TRUE) { pdf("growth-yield.pdf", height=10, width=10) }
	layout(matrix(c(1,1,2,3), nrow=2, byrow=TRUE), height=c(10,10,10,10))
	plot( TNT, pch=20, type="b", xlab="Generation, t", ylab=expression(N[t]), main="Plant Growth Yield Model", lwd=2 )
	plot.new()
	plot_cobweb_growth_yield(TNT,params$gycobweb)
	if (params$gyPDF==TRUE) { 
		print("Plotted to file 'growth-yield.pdf'.")
		dev.off()
	}
}

reset_default_params_growth_yield_GUI <- function() {
	setWinVal(c(gylambda=1.86, gya=1, gyb=1.5, gyNi=1, gyTmax=40), "mainWinSSG")
}

showEqn_growth_yield <- function() {
	createWin("eqnGrowthYield.win")
}

createWin("407.SSG.models.win")

